from distutils.core import setup

setup(name='Game',
      version='1.1',
      author='Mateusz Sidło',
      author_email='314380@uwr.edu.pl',
      packages=['Game'],
      )
